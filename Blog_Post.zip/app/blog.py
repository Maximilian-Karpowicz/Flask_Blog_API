import json


class Blog:
    
    @classmethod
    def ping(cls, status: int) -> dict:
        success = False
        if status == 200:
            success = True
        return json.dumps({'success':success})
    
    @classmethod
    def organize_posts(cls, args: dict, posts: dict) -> dict:
        # Get sortBy argument and check if it is valid.
        sortBy = args.get('sortBy')
        sort_list = ['id','reads','likes','popularity']
        if sortBy == None:
            sortBy = 'id'
        if sortBy not in sort_list:
            return {'error': "sortBy parameter is invalid."}, 400
        # Check if direction is valid.
        direction = args.get('direction')
        dir_list = ['desc','asc']
        r = False
        if direction == 'desc':
            r = True
        if direction not in dir_list and direction != None:
            return {'error': "direction parameter is invalid."}, 400
        to_organize = posts.get('posts')
        # removes duplicates
        ids = set()
        list_of_posts = []
        for post in to_organize:
            post_id = post.get('id')
            if post_id not in ids:
                list_of_posts.append(post)
                ids.add(post_id)
        organized = sorted(list_of_posts, key = lambda p: p[sortBy], reverse = r)
        return {'posts': organized}
        