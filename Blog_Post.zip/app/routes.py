import requests
import json
# import asyncio
# import aiohttp

from flask import request
from .blog import Blog

from . import app
from . import api


@app.get('/')
def home():
    return 'Hello World!'
@app.get('/api/test')
def test():
    tag_arg = request.args.get('tag')
    response = requests.get(api + '?tag=' + tag_arg).json()
    return response

@app.get('/api/ping')
def ping():
    response = Blog.ping(requests.get(api+'?tag=tech').status_code)
    return response

@app.get('/api/posts')
def posts():
    args = request.args
    response = {'posts': []}
    if args.get('tags') == None:
        return {'error': "Tags parameter is required"}
    str(args.get('tags').split(','))
    for tag in list(args.get('tags').split(',')):
        posts = requests.get(api + '?tag=' + tag).json()
        #posts = json.loads(posts)
        response['posts'] = response['posts'] + posts['posts']
    response = Blog.organize_posts(args, response)
    return response