from flask import Flask

app = Flask(__name__)
api = 'https://api.hatchways.io/assessment/blog/posts'

from . import routes