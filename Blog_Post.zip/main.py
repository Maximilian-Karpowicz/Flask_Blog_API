from app import app

if __name__ == "main":
    app.run(port=5000, debug=True, threaded=True)